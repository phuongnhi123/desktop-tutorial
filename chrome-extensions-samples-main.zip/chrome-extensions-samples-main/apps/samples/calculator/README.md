<a target="_blank" href="https://chrome.google.com/webstore/detail/pelimflkpjiicnajdjcmekpioacmahkh">![Try it now in CWS](https://raw.github.com/GoogleChrome/chrome-extensions-samples/master/apps/tryitnowbutton.png "Click here to install this sample from the Chrome Web Store")</a>


# Calculator

A sample application that provides a simple calculator. Supports basic operations
such as addition, multiplication, subtraction and division.

This sample also incorporates an MVC-style structure and requires jQuery for
DOM manipulation.

## APIs

* [Runtime](http://developer.chrome.com/apps/app.runtime.html)
* [Window](http://developer.chrome.com/apps/app.window.html)

     
## Screenshot
![screenshot](/apps/samples/calculator/assets/screenshot_1280_800.png)

