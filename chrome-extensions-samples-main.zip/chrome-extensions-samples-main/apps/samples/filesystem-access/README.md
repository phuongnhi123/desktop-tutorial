<a target="_blank" href="https://chrome.google.com/webstore/detail/ehbhjpchdgepkgjhfkhpkjdbnljedllm">![Try it now in CWS](https://raw.github.com/GoogleChrome/chrome-extensions-samples/master/apps/tryitnowbutton.png "Click here to install this sample from the Chrome Web Store")</a>


# Filesystem access

Shows basic usage of accessing (read/write) files and directories using the `chrome.fileSystem` API.

NOTE: This sample requires Milestone 31 or later of Chrome, since it uses the new directory permission.

## APIs

* [chrome.fileSystem](http://developer.chrome.com/apps/fileSystem.html)
     
## Screenshot
![screenshot](/apps/samples/filesystem-access/assets/screenshot_1280_800.png)

