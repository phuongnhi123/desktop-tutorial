<a target="_blank" href="https://chrome.google.com/webstore/detail/nmlcgjldnboapnjdmllfcdenlljfjanm">![Try it now in CWS](https://raw.github.com/GoogleChrome/chrome-extensions-samples/master/apps/tryitnowbutton.png "Click here to install this sample from the Chrome Web Store")</a>


Low-Energy Heart Rate Sensor
============================

This sample demonstrates using the chrome.bluetoothLowEnergy API to communicate
with the Generic Attribute Profile (GATT) based Heart Rate Service on a
Bluetooth Low Energy heart rate sensor.


## Screenshot
![screenshot](/apps/samples/bluetooth-samples/heart-rate-sensor/assets/screenshot_1280_800.png)
