package passAudio;


import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils; 
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;

import ai.rev.speechtotext.ApiClient;
import ai.rev.speechtotext.models.asynchronous.RevAiJob;
import net.sourceforge.tess4j.ITesseract;
import net.sourceforge.tess4j.Tesseract;

public class Click {
	 public static  void pause(Integer milliseconds){
	        try {
	            TimeUnit.MILLISECONDS.sleep(milliseconds);
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }
	    }
public static void main(String[] args) throws Exception {
	String accessToken = "02pkuvIK6XcqITI7hk8x_U5rrqiRrvQUgfJVFfxW-bjlwJwpul4a94nn_f_ZXyyGltmUFdlOimon6hopj3B_Ep62cRk0E";
	ApiClient apiClient = new ApiClient(accessToken);
	
	
	FirefoxProfile profile = new FirefoxProfile();
    profile.setPreference("browser.cache.disk.enable", false);
    profile.setPreference("browser.cache.memory.enable", false);
    profile.setPreference("browser.cache.offline.enable", false);
    profile.setPreference("network.http.use-cache", false); 
	  System.setProperty("webdriver.gecko.driver","src/lib/geckodriver.exe"); 
	
	FirefoxOptions options = new FirefoxOptions(); 
    options = new FirefoxOptions(); 
    options.setProfile(profile);
    options.setBinary("C:\\Program Files\\Mozilla Firefox/firefox.exe"); 
//    options.addArguments("--headless");     
//    options.addArguments("--disable-gpu");
//    options.addArguments("--window-size=1400,800"); 
	WebDriver driver = new FirefoxDriver(options); 
	// Set implicit wait
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			JavascriptExecutor js = (JavascriptExecutor) driver;  
//			js.executeScript(Script,Arguments);
			// Maximize window
			driver.manage().window().maximize();
	driver.get("https://recaptcha-demo.appspot.com/recaptcha-v2-checkbox.php"); 
	 
	//Thread.sleep(3000);
	WebElement in= driver.findElement(By.xpath("/html/body/main/form/fieldset/label[1]/input"));
	in.sendKeys("testtest");
 
	WebElement response= driver.findElement(By.xpath("//*[@id=\"g-recaptcha-response\"]"));
    String  tex=response.getText();	
 while(tex==null||tex.equals("")) {

	
 	WebElement checkbox=null;
	
	try {
		checkbox= driver.findElement(By.xpath("//iframe[contains(@src, 'recaptcha') and not(@title='recaptcha challenge')]")) ;
		
//		Object aa=js.executeScript("var items = {};"
//					+ " for (index = 0; index < arguments[0].attributes.length; ++index) "
//					+ "{ items[arguments[0].attributes[index].name] = arguments[0].attributes[index].value }; return items;", checkbox);
//			System.out.println("checkbox-----"+aa.toString());
		checkbox.click(); 
	     
		 
	} catch (Exception e) {
		 
		// TODO: handle exception
	}
	
	System.out.println("da check");
	driver.switchTo().frame( driver.findElement( By.xpath("//iframe[contains(@src, 'recaptcha') and (@title='recaptcha challenge')]")));
	try {
		checkbox= driver.findElement(By.xpath("//*[@id=\"recaptcha-audio-button\"]")) ;
		checkbox.click(); 
	     
		 
	} catch (Exception e) {
		 
		// TODO: handle exception
	}
	  
	try {
		System.out.println("click nut moi");
	checkbox= driver.findElement(By.xpath("//*[@id=\"solver-button\"]")) ;
	checkbox.click(); 
     
	} catch (Exception e) {
		
		
	}
	
	
	
	
	
	
		WebElement linksource=null ;
		try {
			 
			 
			 
			
			linksource= driver.findElement(By.cssSelector("#audio-source")); 
			//*[@id="recaptcha-audio-button"]
			
		} catch (Exception e) {
			// TODO: handle exception
		try {
			linksource= driver.findElement(By.id("audio-source"));
		} catch (Exception e2) {
			// TODO: handle exception
			
			try {
				linksource= driver.findElement(By.cssSelector("#audio-source"));
				
			} catch (Exception e3) {
				// TODO: handle exception
				try {
					linksource= driver.findElement(By.xpath("//*[@id=\"audio-source\"]"));
				} catch (Exception e4) {
					// TODO: handle exception
				}
				
				System.out.println("ko thay source");
			}
			
		}
		}
				String link= linksource.getAttribute("src");
		driver.switchTo().defaultContent();
 

		System.out.println(link);
		String linksrc= link.replace(":443", "").replace("amp;", "");
		
 FileUtils.copyURLToFile( new URL(linksrc),  new File("nhat.mp3"),  30000*60,  20000*60);
		
		RevAiJob revAiJob;
		 String id="";
		try {
	revAiJob = apiClient.submitJobLocalFile("nhat.mp3");
	// as plain text
	  System.out.println(revAiJob.getJobId());
	   id = revAiJob.getJobId();
} catch (IOException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
		pause(5000);

		String text = getname(id,apiClient);
		
	
	  
//	String theURL = "https://speech-to-text-demo.ng.bluemix.net/"; 
//	js.executeScript("window.open(arguments[0])",theURL);
//	  ArrayList<String> tabs = new ArrayList<String> (driver.getWindowHandles());
//	// Open APP to download application
//    driver.switchTo().window(tabs.get(1)); //switches to new tab
//	driver.get("https://speech-to-text-demo.ng.bluemix.net/");
//	  
//	// Click on updaload 
//	 driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[5]/button[2]")).click();
//	String path="D:\\kiemtien\\ClickRecaptcha\\nhat.mp3";
////	driver.findElement(By.xpath("//*[@id=\"root\"]/div/input")).sendKeys("path");
//	
//	 
//	 StringSelection strSelection = new StringSelection(path);
//     Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
//     clipboard.setContents(strSelection,null);
//
//   
//	 WebElement textare=null;
//     		try {
//     			  textare = driver.findElement(By.xpath("/html/body/div[3]/div/div[6]/div/div/div/span"));    
//     			 text= textare.getText(); 
//			} catch (Exception e) {
//				// TODO: handle exception
//				 
//			}											 
//     		 
////   
		text=text.replace(".", "").trim();
    System.out.println(text); 
    apiClient.deleteJob(id);
   // driver.switchTo().window(tabs.get(0)); //switches to new tab
    driver.switchTo().frame( driver.findElement( By.xpath("//iframe[contains(@src, 'recaptcha') and (@title='recaptcha challenge')]")));
    WebElement verify=   driver.findElement(By.xpath("//*[@id=\"recaptcha-verify-button\"]"));
    if(verify!=null) {
    	System.out.println("thay nut veri r");
    	
    }
    WebElement inputtext= driver.findElement(By.xpath("//*[@id=\"audio-response\"]"));
    inputtext.sendKeys(text.replace(".", ""));
     
    verify.click();	
    driver.switchTo().defaultContent();
   
	
    response= driver.findElement(By.xpath("//*[@id=\"g-recaptcha-response\"]"));	
 }
	System.out.println("da xac nhận");	
	 driver.findElement(By.xpath("/html/body/main/form/fieldset/button")).click();
	 
	// driver.quit();
		 
	 
	 
	 
	 
	 
	 
}
private static String getname(String id,ApiClient apiClient) {
	String text="";
try {
String transcriptText = apiClient.getTranscriptText(id);
	System.out.println(transcriptText);
    text= transcriptText.split("   ")[2];
	System.out.println(text);
} catch (Exception e) {
	// TODO: handle exception
	return getname(id, apiClient);
	
}
if(text.isEmpty()) {
	return getname(id, apiClient);
	
}

	return text;
}

 
}
