package passAudio;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONException;
import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class Ted {
	
	 public static List<String> parseLinks(final String html) throws Exception {
		    List<String> result = new ArrayList<String>();
		    Document doc = Jsoup.parse(html);

		    Elements numberResult = doc.select("#result-stats");
		    System.out.println(numberResult.text());
		    
		    Elements results = doc.select("a > h3");
		    for (Element link : results) {
		      Elements parent = link.parent().getAllElements();
		      String relHref = parent.attr("href");
		      if (relHref.startsWith("/url?q=")) {
		        relHref = relHref.replace("/url?q=", "");
		      }
		      String[] splittedString = relHref.split("&sa=");
		      if (splittedString.length > 1) {
		        relHref = splittedString[0];
		      }
		      //System.out.println(relHref);
		      result.add(relHref);
		    }
		    return result;
		  }
public static void main(String[] args) throws Exception {
//	String accessToken = "02pkuvIK6XcqITI7hk8x_U5rrqiRrvQUgfJVFfxW-bjlwJwpul4a94nn_f_ZXyyGltmUFdlOimon6hopj3B_Ep62cRk0E";
//	ApiClient apiClient = new ApiClient(accessToken);
//	String urlLinkToFile = "https://www.rev.ai/FTC_Sample_1.mp3";
//	RevAiJob revAiJob;
//	try {
////		revAiJob = apiClient.submitJobUrl(urlLinkToFile);
//		String localPathToFile = "nhat.mp3";
//		  revAiJob = apiClient.submitJobLocalFile(localPathToFile);
//		// as plain text
//		  System.out.println(revAiJob.getJobId());
////		String transcriptText = apiClient.getTranscriptText(revAiJob.getJobId());
////		System.out.println(transcriptText);
//	} catch (IOException e) {
//		// TODO Auto-generated catch block
//		e.printStackTrace();
//	}
	
//	try {
//		String transcriptText = apiClient.getTranscriptText("sjY4Xy02U44t");
//	 System.out.println(transcriptText);
//		String text= transcriptText.split("   ")[2];
//		 System.out.println(text);
//	} catch (Exception e) {
//		// TODO: handle exception
//	}
	
	
	URL url;
	HttpURLConnection con = null;
	try {
		url = new URL("https://try.jsoup.org/fetch?url=https%3A%2F%2Fwww.google.com%2Fsearch%3Fq%3Dnh%E1%BA%A5t%2Bit&ua=Mozilla%2F5.0+(Windows+NT+10.0%3B+Win64%3B+x64%3B+rv%3A88.0)+Gecko%2F20100101+Firefox%2F88.0&parser=html&pretty=on&whitelist=disabled");
	
	  con = (HttpURLConnection) url.openConnection();
	con.setRequestMethod("GET");
	 
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	BufferedReader in = new BufferedReader(
			  new InputStreamReader(con.getInputStream()));
			String inputLine;
			StringBuffer content = new StringBuffer();
			while ((inputLine = in.readLine()) != null) {
			    content.append(inputLine);
			}
			in.close(); 
			JSONObject myResponse = new JSONObject(content.toString());
	  
//	  System.out.println("html- "+myResponse.getString("html"));
		    List<String> links = parseLinks(myResponse.getString("html"));
		   for (String string : links) {
			System.out.println(string);
		}
		    
//	GET a
//			Host: try.jsoup.org
//			User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:88.0) Gecko/20100101 Firefox/88.0
//			Accept: application/json, text/javascript, */*; q=0.01
//			Accept-Language: vi-VN,vi;q=0.8,en-US;q=0.5,en;q=0.3
//			Accept-Encoding: gzip, deflate, br
//			X-Requested-With: XMLHttpRequest
//			Connection: keep-alive
//			Referer: https://try.jsoup.org/
//			Cookie: _ga=GA1.2.575206955.1622115912; _gid=GA1.2.1500908855.1622115912; _gat=1
//			TE: Trailers

}
}
