package passAudio;
import java.io.IOException;
import java.net.URLEncoder;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
 
public class HelloJsoup {  
 
   public static void main( String[] args ) throws IOException{  

		String encoding = "UTF-8";
		
		try {
			String searchText = "nhất it";
			Document doc = Jsoup.connect("https://google.com/?q=" + URLEncoder.encode(searchText, encoding)).userAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Safari/537.36").get();
			 Elements html= doc.select("#result-stats");
			 
			System.out.println(html);
			 
//			
//			String info = doc.select("div#resultStats").text();
//			    System.out.println(info);
//			 
//			if (info==null||info.isEmpty()) {
//				System.out.println("No results found");
//				return;
//			}
			
//			webSitesLinks.forEach(link->System.out.println(link.text()));
			
			//========If you want to get the first link ================
			//String firstWebSiteLink = webSitesLinks.get(0).text();
			
//			System.out.println(info);
			
			//Move to the next page code..
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		

   }  
 
}