package passAudio;

import java.awt.AWTException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;

public class Login {
	
private  FirefoxDriver driver;
private FirefoxOptions options; 
String query = "";
JavascriptExecutor js;
public Login() throws IOException {
	

 	FirefoxProfile profile = new FirefoxProfile();
     profile.setPreference("browser.cache.disk.enable", false);
     profile.setPreference("browser.cache.memory.enable", false);
     profile.setPreference("browser.cache.offline.enable", false);
     profile.setPreference("network.http.use-cache", false); 
 
	   System.setProperty("webdriver.gecko.driver","src/lib/geckodriver.exe"); 
	     options = new FirefoxOptions(); 
	     options.setProfile(profile);
	  //   options.setBinary("C:\\Program Files (x86)\\Mozilla Firefox\\firefox.exe"); 
	     //options.addArguments("--headless");  
	     driver = new FirefoxDriver(options); 
 
	     driver.manage().window().maximize(); 
	     driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			 js = (JavascriptExecutor) driver; 
			
			search();
	     
	}




	private void search() throws IOException {
		
		
		
		
		
		
		
		    String searchTerm = "nam linh chi do";
		    System.out.println("Google Search Parser Tutorial");
		    System.out.println("Searching for: " + searchTerm);
			String encoding = "UTF-8";
		    try {
			 query = "https://www.google.com/search?q=" +  URLEncoder.encode(searchTerm, encoding) ;
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  	
		
		
driver.get("https://try.jsoup.org/");

WebElement element= getElement("dialogFetchButton", "id");
 clickElm(element);


WebElement eInputLink= getElement("fetchUrl", "id");
 senkey(eInputLink,query);
 
 
WebElement dom= getElement("htmlInput", "id");


//Document doc = Jsoup.parse(html);

Object aa  =   js.executeScript("var items = {};"
			+ " for (index = 0; index < arguments[0].attributes.length; ++index) "
			+ "{ items[arguments[0].attributes[index].name] = arguments[0].attributes[index].value }; return items;", dom);
	System.out.println("tét-----"+aa.toString());
List<String> listLink = new ArrayList<String>();
try {
	  listLink = parseLinks( dom.getText());
} catch (Exception e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
 
for (String string : listLink) {
	System.out.println(string);
}

}
	
	

	 public static List<String> parseLinks(final String html) throws Exception {
		    List<String> result = new ArrayList<String>();
		    Document doc = Jsoup.parse(html);
		     
		    Elements results = doc.select("a > h3");
		    for (Element link : results) {
		      Elements parent = link.parent().getAllElements();
		      String relHref = parent.attr("href");
		      if (relHref.startsWith("/url?q=")) {
		        relHref = relHref.replace("/url?q=", "");
		      }
		      String[] splittedString = relHref.split("&sa=");
		      if (splittedString.length > 1) {
		        relHref = splittedString[0];
		      }
		      //System.out.println(relHref);
		      result.add(relHref);
		    }
		    return result;
		  }


private void senkey(WebElement eInputLink, String query2) {

if(eInputLink.isEnabled()) {
	eInputLink.sendKeys(query,Keys.ENTER);
}
	}




	private void clickElm(WebElement element) {
		// TODO Auto-generated method stub
		if(element.isEnabled()) {
			element.click();
		}

	}




	private WebElement getElement(String key, String type) {
		WebElement elm =null;
	try {
		switch (type) {
		case "class":
			elm =  driver.findElement(By.className(key)); 
			break;
       case "id":
    	   elm =   driver.findElement(By.id(key)); 
			break;
       case "xpath":
    	   elm =   driver.findElement(By.xpath(key)); 
			break; 
       case "css":
    	   elm =   driver.findElement(By.cssSelector(key)); 
			break;
		default:
			
			break;
		}
		
		
	} catch (Exception e) {
		// TODO: handle exception
	}
		return elm;
	}
	

	public void closeweb() {
		driver.quit();
    
	}
    
    public void pause(Integer milliseconds){
        try {
            TimeUnit.MILLISECONDS.sleep(milliseconds);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

public static void main(String[] args) throws InterruptedException, AWTException, MalformedURLException, IOException {
  
	Login l= new Login();
	
	
}
}
